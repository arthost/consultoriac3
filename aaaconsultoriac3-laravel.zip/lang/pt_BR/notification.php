<?php

return [
    'new_register' => [
        'title' => 'Seu cadastro foi concluído com sucesso!',
        'body' => 'O acesso ao sistema deve precisa ser liberado por um administrador do sistema. \n\nVocê receberá um e-mail com o link de acesso ao sistema.',
    ]
];
