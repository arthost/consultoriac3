<?php

namespace App\Filament\Partner\Widgets;

use Filament\Widgets\Widget;

class PartnerCodeWidget extends Widget
{
    protected static string $view = 'filament.partner.widgets.partner-code-widget-custom';
}
