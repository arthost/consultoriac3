<?php

return [
    'reset' => 'Sua senha foi redefinida.',
    'sent' => 'Enviamos o link para redefinição de senha para o seu email.',
    'throttled' => 'Por favor, aguarde antes de tentar novamente.',
    'token' => 'Este token de redefinição de senha é inválido.',
    'user' => "Não conseguimos encontrar um usuário com esse endereço de e-mail.",
];
