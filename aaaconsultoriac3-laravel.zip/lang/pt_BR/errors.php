<?php

return [
    'Unauthorized' => 'Não autorizado',
    'Payment Required' => 'Pagamento requerido',
    'Forbidden' => 'Proibido',
    'Not Found' => 'Não encontrado',
    'Page Expired' => 'Página expirada',
    'Too Many Requests' => 'Muitas requisições',
    'Server Error' => 'Erro do Servidor',
    'Service Unavailable' => 'Serviço Indisponível',
];
