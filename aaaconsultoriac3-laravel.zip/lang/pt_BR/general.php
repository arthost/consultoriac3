<?php

return [
    'created_at' => 'Data de criação',
    'updated_at' => 'Data de atualização',
    'deleted_at' => 'Data de exclusão',
    'user_type' => 'Tipo de Usuário',
    'social_name' => 'Razão Social',
    'partner_code' => 'Código Pessoal',
    'created_by' => 'Parceiro',
    'partner_type' => 'Tipo de Parceiro',
];
